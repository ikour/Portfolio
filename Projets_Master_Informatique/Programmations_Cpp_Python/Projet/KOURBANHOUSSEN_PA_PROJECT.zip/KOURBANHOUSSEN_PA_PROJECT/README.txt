*****KOURBANHOUSSEN Idriss*****

Project : Fencing 

- Avant de commencer, veuillez vérifiez que la bibliothèque curses et la bibliothèque tkinter est bien présent sur votre ordinateur
- Pour joueur au jeu, se mettre dans le repertoire courant contenant le fichier main.py
- réaliser la commande: python3 main.py
    - "Voulez-vous utiliser jouer sur la version Terminal ou Graphique (T/G)?"
        => taper T pour ouvir le jeu en version terminale et G en version Graphique
    - "Combiens d'images par secondes voulez-vous (20 conseillé)?"
        => taper le nombre de rafraichissement de la fenètre que vous voulez par secondes
    - "Voulez-vous reprendre la Partie enregistrée (Y/N)?"
        => taper la touche Y pour reprendre la paritie enregistrer ou N pour commencer une nouvelle Partie
        => Si vous avez appuyé sur Y la partie va automatiquement commencer
    - "Choisissez le numéro de la scène :"
        => taper le numéro de la scène que vous voulez parmis ceux proposé à l'écran
    - "Voulez-vous modifier les attributs par défauts des joueurs (Y/N) ?"
        => taper la touche Y pour choisir les valeurs des attributs des joueurs ou N pour garder les attribut par défauts
        => si vous avez appuyé sur N la partie va automatiquement commencer
        => si vous avez appuyé sur Y vous allez préciser la valeur de chaque attribut de chaque joueur

- Version Terminal:
    - pour quitter appuyez sur menu et ensuite sur quitter
    - pour mettre en pause appuyez sur menu et ensuite sur reprendre
    - pour enregistrer la partie appuyez sur menu et ensuite sur enregistrer
    - les commandes utilisateur sont consultable dans le menu

- Version Graphique:
    - pour quitter appuyez sur le bouton quitter
    - pour enregistrer la partie appuyez sur le bouton enregistrer
    - les commandes utilisateur sont consultable directement sur l'interface